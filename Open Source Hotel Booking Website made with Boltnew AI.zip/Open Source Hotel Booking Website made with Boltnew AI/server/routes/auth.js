import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const router = express.Router();

export default function authRoutes(db) {
  // Customer login route
  router.post('/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ 
          success: false, 
          error: 'Email and password are required' 
        });
      }

      const user = await db.get('SELECT * FROM users WHERE email = ? AND isAdmin = 0', [email]);

      if (!user) {
        return res.status(401).json({ 
          success: false, 
          error: 'Invalid credentials' 
        });
      }

      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ 
          success: false, 
          error: 'Invalid credentials' 
        });
      }

      const token = jwt.sign(
        { 
          id: user.id,
          email: user.email,
          fullName: user.fullName,
          isAdmin: false 
        },
        process.env.JWT_SECRET || 'your-super-secret-key-change-in-production',
        { expiresIn: '24h' }
      );

      res.cookie('token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 24 * 60 * 60 * 1000
      });

      res.json({
        success: true,
        user: {
          id: user.id,
          email: user.email,
          fullName: user.fullName,
          isAdmin: false
        }
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ 
        success: false, 
        error: 'Internal server error' 
      });
    }
  });

  // Admin login route
  router.post('/admin/login', async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ 
          success: false, 
          error: 'Email and password are required' 
        });
      }

      const admin = await db.get('SELECT * FROM users WHERE email = ? AND isAdmin = 1', [email]);

      if (!admin) {
        return res.status(401).json({ 
          success: false, 
          error: 'Invalid admin credentials' 
        });
      }

      const validPassword = await bcrypt.compare(password, admin.password);
      if (!validPassword) {
        return res.status(401).json({ 
          success: false, 
          error: 'Invalid admin credentials' 
        });
      }

      const token = jwt.sign(
        { 
          id: admin.id,
          email: admin.email,
          fullName: admin.fullName,
          isAdmin: true 
        },
        process.env.JWT_SECRET || 'your-super-secret-key-change-in-production',
        { expiresIn: '24h' }
      );

      res.cookie('adminToken', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 24 * 60 * 60 * 1000
      });

      res.json({
        success: true,
        user: {
          id: admin.id,
          email: admin.email,
          fullName: admin.fullName,
          isAdmin: true
        }
      });
    } catch (error) {
      console.error('Admin login error:', error);
      res.status(500).json({ 
        success: false, 
        error: 'Internal server error' 
      });
    }
  });

  // Register route
  router.post('/register', async (req, res) => {
    try {
      const { email, password, fullName, phone } = req.body;

      // Check if user already exists
      const existingUser = await db.get('SELECT * FROM users WHERE email = ?', [email]);
      if (existingUser) {
        return res.status(400).json({
          success: false,
          error: 'Email already registered'
        });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create user
      const result = await db.run(`
        INSERT INTO users (email, password, fullName, phone, isAdmin, verified)
        VALUES (?, ?, ?, ?, 0, 1)
      `, [email, hashedPassword, fullName, phone]);

      res.json({
        success: true,
        message: 'Registration successful'
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to register user'
      });
    }
  });

  // Logout route
  router.post('/logout', (req, res) => {
    res.clearCookie('token');
    res.clearCookie('adminToken');
    res.json({ success: true, message: 'Logged out successfully' });
  });

  return router;
}