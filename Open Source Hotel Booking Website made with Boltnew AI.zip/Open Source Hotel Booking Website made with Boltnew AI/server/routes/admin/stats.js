import express from 'express';
import { authenticateToken, isAdmin } from '../../middleware/auth.js';

const router = express.Router();

export default function statsRoutes(db) {
  router.get('/', authenticateToken, isAdmin, async (req, res) => {
    try {
      // Get total bookings
      const totalBookings = await db.get('SELECT COUNT(*) as count FROM bookings');
      if (!totalBookings) throw new Error('Failed to fetch total bookings');

      // Get active customers
      const activeCustomers = await db.get('SELECT COUNT(DISTINCT customerEmail) as count FROM bookings');
      if (!activeCustomers) throw new Error('Failed to fetch active customers');

      // Get total published rooms
      const totalRooms = await db.get('SELECT COUNT(*) as count FROM rooms WHERE status = "published"');
      if (!totalRooms) throw new Error('Failed to fetch total rooms');
      
      // Get current occupancy
      const currentDate = new Date().toISOString().split('T')[0];
      const occupiedRooms = await db.get(`
        SELECT COUNT(DISTINCT roomName) as count 
        FROM bookings 
        WHERE status = 'confirmed' 
        AND date(?) BETWEEN date(checkIn) AND date(checkOut)
      `, [currentDate]);
      if (!occupiedRooms) throw new Error('Failed to fetch occupied rooms');

      // Calculate occupancy rate
      const roomOccupancy = totalRooms.count > 0 
        ? Math.round((occupiedRooms.count / totalRooms.count) * 100)
        : 0;

      // Calculate total revenue
      const revenue = await db.get(`
        SELECT COALESCE(SUM(r.price * (julianday(b.checkOut) - julianday(b.checkIn))), 0) as total
        FROM bookings b
        JOIN rooms r ON b.roomName = r.name
        WHERE b.status = 'confirmed'
      `);
      if (!revenue) throw new Error('Failed to fetch revenue');

      res.json({
        success: true,
        stats: {
          totalBookings: totalBookings.count || 0,
          activeCustomers: activeCustomers.count || 0,
          roomOccupancy: roomOccupancy || 0,
          revenue: Math.round(revenue.total || 0)
        }
      });
    } catch (error) {
      console.error('Stats error:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message || 'Failed to fetch statistics' 
      });
    }
  });

  return router;
}