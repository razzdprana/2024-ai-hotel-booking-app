import express from 'express';
import { authenticateToken, isAdmin } from '../../middleware/auth.js';

const router = express.Router();

export default function roomsRoutes(db) {
  // Get all rooms
  router.get('/', authenticateToken, isAdmin, async (req, res) => {
    try {
      const rooms = await db.all(`
        SELECT 
          id,
          name,
          description,
          price,
          image,
          capacity,
          amenities,
          status,
          createdAt
        FROM rooms 
        ORDER BY createdAt DESC
      `);

      // Parse amenities JSON string to array
      const formattedRooms = rooms.map(room => ({
        ...room,
        amenities: JSON.parse(room.amenities || '[]')
      }));

      res.json({ success: true, rooms: formattedRooms });
    } catch (error) {
      console.error('Fetch rooms error:', error);
      res.status(500).json({ success: false, error: 'Failed to fetch rooms' });
    }
  });

  // Get single room
  router.get('/:id', authenticateToken, isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      
      const room = await db.get(`
        SELECT 
          id,
          name,
          description,
          price,
          image,
          capacity,
          amenities,
          status,
          createdAt
        FROM rooms 
        WHERE id = ?
      `, [id]);

      if (!room) {
        return res.status(404).json({ success: false, error: 'Room not found' });
      }

      // Parse amenities JSON string to array
      const formattedRoom = {
        ...room,
        amenities: JSON.parse(room.amenities || '[]')
      };

      res.json({ success: true, room: formattedRoom });
    } catch (error) {
      console.error('Fetch room error:', error);
      res.status(500).json({ success: false, error: 'Failed to fetch room' });
    }
  });

  // Create room
  router.post('/', authenticateToken, isAdmin, async (req, res) => {
    try {
      const { name, description, price, image, capacity, amenities, status } = req.body;
      
      const result = await db.run(`
        INSERT INTO rooms (name, description, price, image, capacity, amenities, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [name, description, price, image, capacity, JSON.stringify(amenities), status]);

      res.json({ 
        success: true, 
        roomId: result.lastID,
        message: 'Room created successfully'
      });
    } catch (error) {
      console.error('Create room error:', error);
      res.status(500).json({ success: false, error: 'Failed to create room' });
    }
  });

  // Update room
  router.put('/:id', authenticateToken, isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { name, description, price, image, capacity, amenities, status } = req.body;
      
      await db.run(`
        UPDATE rooms 
        SET name = ?, description = ?, price = ?, image = ?, capacity = ?, amenities = ?, status = ?
        WHERE id = ?
      `, [name, description, price, image, capacity, JSON.stringify(amenities), status, id]);

      res.json({ 
        success: true,
        message: 'Room updated successfully'
      });
    } catch (error) {
      console.error('Update room error:', error);
      res.status(500).json({ success: false, error: 'Failed to update room' });
    }
  });

  return router;
}