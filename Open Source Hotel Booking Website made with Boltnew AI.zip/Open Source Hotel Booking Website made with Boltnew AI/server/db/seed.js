import { open } from 'sqlite';
import sqlite3 from 'sqlite3';
import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));

async function seed() {
  try {
    const db = await open({
      filename: join(__dirname, 'database.sqlite'),
      driver: sqlite3.Database
    });

    // Create admin user
    const adminPassword = await bcrypt.hash('admin123', 10);
    await db.run(`
      INSERT OR REPLACE INTO users (email, password, fullName, isAdmin, verified)
      VALUES (?, ?, ?, 1, 1)
    `, ['admin@hotel.com', adminPassword, 'Hotel Admin']);

    console.log('Database seeded successfully');
    await db.close();
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
}

seed();