import React, { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { jwtDecode } from 'jwt-decode';
import toast from 'react-hot-toast';

interface AdminUser {
  id: number;
  email: string;
  fullName: string;
  isAdmin: boolean;
}

interface AdminAuthContextType {
  admin: AdminUser | null;
  isAdminAuthenticated: boolean;
  adminLogin: (email: string, password: string) => Promise<void>;
  adminLogout: () => Promise<void>;
}

const AdminAuthContext = createContext<AdminAuthContextType | null>(null);

export const useAdminAuth = () => {
  const context = useContext(AdminAuthContext);
  if (!context) {
    throw new Error('useAdminAuth must be used within an AdminAuthProvider');
  }
  return context;
};

export const AdminAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [admin, setAdmin] = useState<AdminUser | null>(null);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = () => {
      const token = document.cookie
        .split('; ')
        .find(row => row.startsWith('adminToken='))
        ?.split('=')[1];

      if (token) {
        try {
          const decodedToken = jwtDecode(token) as any;
          if (decodedToken.exp * 1000 > Date.now() && decodedToken.isAdmin) {
            setAdmin({
              id: decodedToken.id,
              email: decodedToken.email,
              fullName: decodedToken.fullName,
              isAdmin: true
            });
            setIsAdminAuthenticated(true);
          } else {
            handleLogout();
          }
        } catch (error) {
          handleLogout();
        }
      }
    };

    checkAuth();
  }, []);

  const handleLogout = async () => {
    setAdmin(null);
    setIsAdminAuthenticated(false);
    document.cookie = 'adminToken=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
  };

  const adminLogin = async (email: string, password: string) => {
    try {
      const res = await fetch('/api/auth/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email, password }),
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || 'Invalid admin credentials');
      }

      const data = await res.json();
      
      if (!data.success || !data.user.isAdmin) {
        throw new Error('Invalid admin credentials');
      }

      setAdmin(data.user);
      setIsAdminAuthenticated(true);
      toast.success('Logged in as admin');
      navigate('/admin/dashboard');
    } catch (error) {
      console.error('Admin login error:', error);
      handleLogout();
      throw error;
    }
  };

  const adminLogout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });
      handleLogout();
      navigate('/admin/login');
    } catch (error) {
      console.error('Admin logout error:', error);
      handleLogout();
      navigate('/admin/login');
    }
  };

  return (
    <AdminAuthContext.Provider value={{ admin, isAdminAuthenticated, adminLogin, adminLogout }}>
      {children}
    </AdminAuthContext.Provider>
  );
};