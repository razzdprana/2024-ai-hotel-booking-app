import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { RoomCard } from './RoomCard';
import { BookingForm } from './BookingForm';
import { rooms } from '../data/rooms';
import { Room, BookingDetails } from '../types';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

export const RoomsPage = () => {
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const location = useLocation();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  const [bookingForm, setBookingForm] = useState({
    checkIn: '',
    checkOut: '',
    guests: '2',
    roomType: rooms[0]?.name || ''
  });

  // Initialize form with booking data if it exists
  useEffect(() => {
    const bookingData = location.state?.bookingData;
    if (bookingData) {
      setBookingForm({
        checkIn: bookingData.checkIn,
        checkOut: bookingData.checkOut,
        guests: String(bookingData.guests),
        roomType: bookingData.roomName
      });
    }
  }, [location.state]);

  const handleBookingSubmit = async (details: BookingDetails) => {
    if (!isAuthenticated) {
      navigate('/login', { 
        state: { 
          bookingData: {
            checkIn: details.checkIn,
            checkOut: details.checkOut,
            guests: details.guests,
            roomName: details.room.name
          }
        }
      });
      return;
    }

    try {
      const user = JSON.parse(localStorage.getItem('user') || '{}');
      
      const res = await fetch('/api/admin/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          customerEmail: user.email,
          customerName: user.fullName,
          roomName: details.room.name,
          checkIn: details.checkIn.toISOString().split('T')[0],
          checkOut: details.checkOut.toISOString().split('T')[0],
          guests: details.guests,
          status: 'pending'
        })
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Booking failed');
      }

      toast.success('Booking request sent successfully!');
      navigate('/dashboard');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Failed to submit booking');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      {!selectedRoom ? (
        <>
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Our Rooms & Suites
            </h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Choose from our carefully curated selection of luxury rooms and suites.
              Each room is designed to provide the ultimate comfort and relaxation during your stay.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {rooms.map((room) => (
              <RoomCard
                key={room.id}
                room={room}
                onSelect={setSelectedRoom}
              />
            ))}
          </div>
        </>
      ) : (
        <BookingForm
          selectedRoom={selectedRoom}
          onSubmit={handleBookingSubmit}
          onBack={() => setSelectedRoom(null)}
        />
      )}
    </div>
  );
};