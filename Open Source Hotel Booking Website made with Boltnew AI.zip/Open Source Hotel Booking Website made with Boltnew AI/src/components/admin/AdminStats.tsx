import React, { useState, useEffect } from 'react';
import { Users, Hotel, Calendar, DollarSign } from 'lucide-react';
import toast from 'react-hot-toast';
import { Skeleton } from '../Skeleton';

interface Stats {
  totalBookings: number;
  activeCustomers: number;
  roomOccupancy: number;
  revenue: number;
}

const StatCard = ({ title, value, icon: Icon, color }: {
  title: string;
  value: string;
  icon: React.ElementType;
  color: string;
}) => (
  <div className="bg-white rounded-lg shadow-md p-6">
    <div className="flex items-center justify-between mb-4">
      <div className={`p-3 rounded-lg bg-${color}-100`}>
        <Icon className={`text-${color}-600`} size={24} />
      </div>
    </div>
    <h3 className="text-2xl font-bold mb-1">{value}</h3>
    <p className="text-gray-600">{title}</p>
  </div>
);

export const AdminStats = () => {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/admin/stats', {
        credentials: 'include'
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Failed to fetch statistics');
      }

      const data = await res.json();
      
      if (!data.success) {
        throw new Error(data.error || 'Failed to fetch statistics');
      }
      
      setStats(data.stats);
    } catch (error) {
      console.error('Stats error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to load statistics');
      setStats(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  if (loading) {
    return (
      <div>
        <h2 className="text-2xl font-bold mb-6">Dashboard Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <Skeleton className="h-12 w-12 rounded-lg" />
              </div>
              <Skeleton className="h-8 w-24 mb-2" />
              <Skeleton className="h-4 w-32" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="text-center py-12">
        <div className="text-gray-400 mb-4">
          <Calendar className="mx-auto h-12 w-12" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">
          No statistics available
        </h3>
        <button
          onClick={fetchStats}
          className="text-blue-600 hover:text-blue-800"
        >
          Refresh Statistics
        </button>
      </div>
    );
  }

  const statCards = [
    {
      title: 'Total Bookings',
      value: stats.totalBookings.toString(),
      icon: Calendar,
      color: 'blue'
    },
    {
      title: 'Active Customers',
      value: stats.activeCustomers.toString(),
      icon: Users,
      color: 'green'
    },
    {
      title: 'Room Occupancy',
      value: `${stats.roomOccupancy || 0}%`,
      icon: Hotel,
      color: 'purple'
    },
    {
      title: 'Revenue',
      value: `$${stats.revenue.toLocaleString()}`,
      icon: DollarSign,
      color: 'yellow'
    }
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Dashboard Overview</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((stat, index) => (
          <StatCard key={index} {...stat} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">New booking received</span>
              <span className="text-gray-500">2 minutes ago</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Room status updated</span>
              <span className="text-gray-500">15 minutes ago</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">New customer registered</span>
              <span className="text-gray-500">1 hour ago</span>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">Popular Rooms</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Deluxe Ocean View Suite</span>
              <span className="text-green-600 font-medium">85% booked</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Garden Villa</span>
              <span className="text-green-600 font-medium">75% booked</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Executive Mountain Suite</span>
              <span className="text-yellow-600 font-medium">60% booked</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};