import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Facebook, Twitter } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-8 mt-auto">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          <div className="text-center sm:text-left">
            <h3 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">Contact Us</h3>
            <p className="text-sm sm:text-base text-gray-300">123 Beach Road</p>
            <p className="text-sm sm:text-base text-gray-300">Paradise Island</p>
            <p className="text-sm sm:text-base text-gray-300">contact@luxurybeachresort.com</p>
          </div>
          <div className="text-center sm:text-left">
            <h3 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/about" className="text-sm sm:text-base text-gray-300 hover:text-blue-400">About Us</Link></li>
              <li><Link to="/rooms" className="text-sm sm:text-base text-gray-300 hover:text-blue-400">Our Rooms</Link></li>
              <li><Link to="/experience" className="text-sm sm:text-base text-gray-300 hover:text-blue-400">Experience</Link></li>
            </ul>
          </div>
          <div className="text-center sm:text-left">
            <h3 className="text-base sm:text-lg font-semibold mb-3 sm:mb-4">Follow Us</h3>
            <div className="flex justify-center sm:justify-start space-x-4">
              <a href="#" className="text-gray-300 hover:text-blue-400">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-blue-400">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-gray-300 hover:text-blue-400">
                <Twitter size={20} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};