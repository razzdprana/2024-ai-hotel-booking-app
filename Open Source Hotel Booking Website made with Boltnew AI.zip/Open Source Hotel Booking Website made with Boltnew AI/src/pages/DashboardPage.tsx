import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookingsList } from '../components/dashboard/BookingsList';
import { ProfileSection } from '../components/dashboard/ProfileSection';
import { DocumentsSection } from '../components/dashboard/DocumentsSection';
import { DashboardNav } from '../components/dashboard/DashboardNav';

export const DashboardPage = () => {
  const [activeSection, setActiveSection] = useState('bookings');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const user = localStorage.getItem('user');
    if (!user) {
      navigate('/login');
    } else {
      setIsAuthenticated(true);
    }
  }, [navigate]);

  const renderSection = () => {
    switch (activeSection) {
      case 'bookings':
        return <BookingsList />;
      case 'profile':
        return <ProfileSection />;
      case 'documents':
        return <DocumentsSection />;
      default:
        return <BookingsList />;
    }
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <DashboardNav activeSection={activeSection} onSectionChange={setActiveSection} />
        <main className="flex-1 p-6 lg:ml-64">
          <div className="max-w-5xl mx-auto bg-white rounded-lg shadow-sm p-6">
            {renderSection()}
          </div>
        </main>
      </div>
    </div>
  );
};