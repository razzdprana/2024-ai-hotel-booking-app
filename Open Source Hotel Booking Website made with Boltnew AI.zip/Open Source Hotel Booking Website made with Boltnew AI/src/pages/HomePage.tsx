import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Calendar, Users } from 'lucide-react';
import { rooms } from '../data/rooms';
import { useAuth } from '../contexts/AuthContext';
import { Slider } from '../components/Slider';

interface Experience {
  title: string;
  description: string;
  image: string;
}

interface Testimonial {
  name: string;
  role: string;
  comment: string;
  rating: number;
  image: string;
}

interface FAQ {
  question: string;
  answer: string;
}

const experiences: Experience[] = [
  {
    title: "Luxury Spa Retreat",
    description: "Indulge in our world-class spa treatments and wellness programs.",
    image: "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?auto=format&fit=crop&q=80&w=1200"
  },
  {
    title: "Fine Dining",
    description: "Experience culinary excellence with our award-winning chefs.",
    image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&q=80&w=1200"
  },
  {
    title: "Water Sports",
    description: "Adventure awaits with our range of exciting water activities.",
    image: "https://images.unsplash.com/photo-1533184580123-b704c4142c61?auto=format&fit=crop&q=80&w=1200"
  },
  {
    title: "Private Beach",
    description: "Relax on our exclusive beach with pristine white sands.",
    image: "https://images.unsplash.com/photo-1510414842594-a61c69b5ae57?auto=format&fit=crop&q=80&w=1200"
  }
];

const testimonials: Testimonial[] = [
  {
    name: "Emily & David",
    role: "Honeymoon Couple",
    comment: "Our honeymoon was absolutely perfect. The staff went above and beyond to make it special.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1516685018646-549198525c1b?auto=format&fit=crop&q=80&w=400"
  },
  {
    name: "Richard Thompson",
    role: "Business Traveler",
    comment: "The perfect blend of luxury and efficiency. My go-to choice for business trips.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400"
  },
  {
    name: "The Martinez Family",
    role: "Family Vacation",
    comment: "Activities for everyone! Our kids didn't want to leave, and neither did we.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1484723091739-30a097e8f929?auto=format&fit=crop&q=80&w=400"
  },
  {
    name: "Lisa Chen",
    role: "Solo Traveler",
    comment: "Felt safe and pampered throughout my stay. The staff became like family.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=400"
  }
];

const faqs: FAQ[] = [
  {
    question: "What are your check-in and check-out times?",
    answer: "Check-in time is 3:00 PM and check-out time is 11:00 AM. Early check-in and late check-out can be arranged based on availability."
  },
  {
    question: "Do you offer airport transfers?",
    answer: "Yes, we offer complimentary airport transfers for all guests. Please provide your flight details at least 24 hours before arrival."
  },
  {
    question: "Is breakfast included in the room rate?",
    answer: "Yes, all room rates include our signature breakfast buffet served at the oceanfront restaurant from 6:30 AM to 10:30 AM."
  },
  {
    question: "What activities are available at the resort?",
    answer: "We offer a wide range of activities including water sports, spa treatments, cooking classes, yoga sessions, and guided tours."
  }
];

export const HomePage = () => {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [bookingForm, setBookingForm] = useState({
    checkIn: '',
    checkOut: '',
    guests: '2',
    roomType: rooms[0]?.name || ''
  });

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // If user is not authenticated, redirect to login with booking data
    if (!isAuthenticated) {
      navigate('/login', { 
        state: { 
          bookingData: {
            checkIn: bookingForm.checkIn,
            checkOut: bookingForm.checkOut,
            guests: parseInt(bookingForm.guests),
            roomName: bookingForm.roomType
          }
        }
      });
      return;
    }

    // If user is authenticated, redirect to the selected room's booking page
    navigate('/rooms', { 
      state: { 
        bookingData: {
          checkIn: bookingForm.checkIn,
          checkOut: bookingForm.checkOut,
          guests: parseInt(bookingForm.guests),
          roomName: bookingForm.roomType
        }
      }
    });
  };

  return (
    <div>
      {/* Hero Section */}
      <div 
        className="h-[70vh] bg-cover bg-center relative"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&q=80&w=1920")'
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="absolute inset-0 flex items-center justify-center p-4">
          <div className="text-center text-white">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Experience Luxury by the Ocean
            </h1>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Discover the perfect blend of comfort, elegance, and natural beauty
              at our exclusive beachfront resort.
            </p>
            <Link
              to="/rooms"
              className="inline-flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Book Your Stay
              <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </div>

      {/* Experiences Section */}
      <section className="py-20 bg-white">
        <Slider
          items={experiences}
          renderItem={(experience: Experience) => (
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img 
                src={experience.image} 
                alt={experience.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{experience.title}</h3>
                <p className="text-gray-600">{experience.description}</p>
              </div>
            </div>
          )}
          title="Unforgettable Experiences"
          subtitle="Create lasting memories with our curated experiences"
        />
      </section>

      {/* Rooms Section */}
      <section className="py-20 bg-gray-50">
        <Slider
          items={rooms}
          renderItem={(room) => (
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img 
                src={room.image} 
                alt={room.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{room.name}</h3>
                <p className="text-gray-600 mb-4">{room.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-xl font-bold">${room.price}</span>
                  <Link
                    to="/rooms"
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          )}
          title="Our Luxury Accommodations"
          subtitle="Choose from our selection of premium rooms and suites"
        />
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-white">
        <Slider
          items={testimonials}
          renderItem={(testimonial: Testimonial) => (
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center gap-4 mb-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-semibold">{testimonial.name}</h3>
                  <p className="text-sm text-gray-600">{testimonial.role}</p>
                </div>
              </div>
              <p className="text-gray-600">{testimonial.comment}</p>
            </div>
          )}
          title="Guest Testimonials"
          subtitle="What our guests say about their stay"
        />
      </section>

      {/* Booking Form Section */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h2 className="text-3xl font-bold mb-6">Book Your Stay</h2>
              <p className="text-lg mb-8">
                Experience luxury and comfort at our beachfront resort.
                Book now and create unforgettable memories.
              </p>
              <ul className="space-y-4">
                <li className="flex items-center gap-2">
                  <ArrowRight size={20} />
                  <span>Best Rate Guarantee</span>
                </li>
                <li className="flex items-center gap-2">
                  <ArrowRight size={20} />
                  <span>Free Cancellation</span>
                </li>
                <li className="flex items-center gap-2">
                  <ArrowRight size={20} />
                  <span>24/7 Customer Support</span>
                </li>
              </ul>
            </div>
            <form onSubmit={handleBookingSubmit} className="bg-white p-6 rounded-lg">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Check-in Date
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="date"
                      required
                      value={bookingForm.checkIn}
                      onChange={(e) => setBookingForm({ ...bookingForm, checkIn: e.target.value })}
                      min={new Date().toISOString().split('T')[0]}
                      className="pl-10 w-full p-2 border rounded-lg"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Check-out Date
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="date"
                      required
                      value={bookingForm.checkOut}
                      onChange={(e) => setBookingForm({ ...bookingForm, checkOut: e.target.value })}
                      min={bookingForm.checkIn || new Date().toISOString().split('T')[0]}
                      className="pl-10 w-full p-2 border rounded-lg"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Guests
                  </label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <select
                      value={bookingForm.guests}
                      onChange={(e) => setBookingForm({ ...bookingForm, guests: e.target.value })}
                      className="pl-10 w-full p-2 border rounded-lg"
                    >
                      {[1, 2, 3, 4, 5, 6].map((num) => (
                        <option key={num} value={num}>
                          {num} Guest{num !== 1 ? 's' : ''}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Room Type
                  </label>
                  <select
                    value={bookingForm.roomType}
                    onChange={(e) => setBookingForm({ ...bookingForm, roomType: e.target.value })}
                    className="w-full p-2 border rounded-lg"
                  >
                    {rooms.map((room) => (
                      <option key={room.id} value={room.name}>
                        {room.name}
                      </option>
                    ))}
                  </select>
                </div>
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Check Availability
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">
            Frequently Asked Questions
          </h2>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-2">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};