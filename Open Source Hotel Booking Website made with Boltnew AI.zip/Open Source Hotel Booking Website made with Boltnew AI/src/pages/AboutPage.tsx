import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Users, Check, Star, Plus, Minus } from 'lucide-react';
import { rooms } from '../data/rooms';
import { Slider } from '../components/Slider';

interface TeamMember {
  name: string;
  role: string;
  bio: string;
  image: string;
}

interface Testimonial {
  name: string;
  role: string;
  comment: string;
  rating: number;
  image: string;
}

interface FAQ {
  question: string;
  answer: string;
}

const teamMembers: TeamMember[] = [
  {
    name: "Robert Chen",
    role: "General Manager",
    bio: "With over 20 years in luxury hospitality, Robert ensures every guest receives exceptional service.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=400"
  },
  {
    name: "Maria Garcia",
    role: "Executive Chef",
    bio: "Award-winning chef bringing culinary excellence with a fusion of local and international flavors.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=400"
  },
  {
    name: "James Wilson",
    role: "Guest Relations Director",
    bio: "Dedicated to creating memorable experiences and exceeding guest expectations.",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=400"
  },
  {
    name: "Sophie Anderson",
    role: "Spa Director",
    bio: "Expert in wellness and relaxation, bringing tranquility to our guests' experience.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400"
  }
];

const testimonials: Testimonial[] = [
  {
    name: "Emily & David",
    role: "Honeymoon Couple",
    comment: "Our honeymoon was absolutely perfect. The staff went above and beyond to make it special.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1516685018646-549198525c1b?auto=format&fit=crop&q=80&w=400"
  },
  {
    name: "Richard Thompson",
    role: "Business Traveler",
    comment: "The perfect blend of luxury and efficiency. My go-to choice for business trips.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400"
  },
  {
    name: "The Martinez Family",
    role: "Family Vacation",
    comment: "Activities for everyone! Our kids didn't want to leave, and neither did we.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1484723091739-30a097e8f929?auto=format&fit=crop&q=80&w=400"
  },
  {
    name: "Lisa Chen",
    role: "Solo Traveler",
    comment: "Felt safe and pampered throughout my stay. The staff became like family.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=400"
  }
];

const faqs: FAQ[] = [
  {
    question: "What makes your resort unique?",
    answer: "Our resort combines luxury amenities with authentic local experiences, set against the backdrop of pristine beaches and lush landscapes. We pride ourselves on personalized service and sustainable practices."
  },
  {
    question: "What sustainability practices do you follow?",
    answer: "We implement various eco-friendly initiatives including solar power, water conservation, waste reduction, local sourcing of ingredients, and supporting local environmental conservation projects."
  },
  {
    question: "Do you offer special packages or seasonal deals?",
    answer: "Yes, we offer various packages including honeymoon specials, family packages, and seasonal promotions. Contact our reservations team for current offers."
  },
  {
    question: "What activities are available at the resort?",
    answer: "We offer a wide range of activities including water sports, cooking classes, yoga sessions, cultural tours, spa treatments, and guided nature walks."
  }
];

const TeamMemberCard: React.FC<TeamMember> = ({ name, role, bio, image }) => (
  <div className="bg-white rounded-lg shadow-lg overflow-hidden h-full">
    <img 
      src={image} 
      alt={name}
      className="w-full h-48 object-cover"
    />
    <div className="p-6">
      <h3 className="text-xl font-semibold mb-1">{name}</h3>
      <p className="text-blue-600 text-sm mb-3">{role}</p>
      <p className="text-gray-600">{bio}</p>
    </div>
  </div>
);

const TestimonialCard: React.FC<Testimonial> = ({ name, role, comment, rating, image }) => (
  <div className="bg-white rounded-lg shadow-lg p-6 h-full">
    <div className="flex items-center gap-4 mb-4">
      <img
        src={image}
        alt={name}
        className="w-12 h-12 rounded-full object-cover"
      />
      <div>
        <h3 className="font-semibold">{name}</h3>
        <p className="text-sm text-gray-600">{role}</p>
      </div>
    </div>
    <div className="flex gap-1 mb-3">
      {[...Array(rating)].map((_, i) => (
        <Star key={i} size={16} className="text-yellow-400 fill-current" />
      ))}
    </div>
    <p className="text-gray-600">{comment}</p>
  </div>
);

const FAQItem: React.FC<FAQ> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border rounded-lg">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-4 text-left"
      >
        <span className="font-medium">{question}</span>
        {isOpen ? (
          <Minus size={20} className="text-gray-500" />
        ) : (
          <Plus size={20} className="text-gray-500" />
        )}
      </button>
      {isOpen && (
        <div className="px-4 pb-4 text-gray-600">
          {answer}
        </div>
      )}
    </div>
  );
};

export const AboutPage = () => {
  const [bookingForm, setBookingForm] = useState({
    checkIn: '',
    checkOut: '',
    guests: '2',
    roomType: rooms[0]?.name || ''
  });

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle booking submission
  };

  return (
    <div>
      {/* Header Section */}
      <div 
        className="h-[60vh] bg-cover bg-center relative"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=1920")'
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="absolute inset-0 flex items-center justify-center p-4">
          <div className="text-center text-white max-w-4xl">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Our Story
            </h1>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              A legacy of luxury hospitality and unforgettable experiences
            </p>
          </div>
        </div>
      </div>

      {/* About the Property */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">A Paradise by the Ocean</h2>
              <p className="text-gray-600 mb-6">
                Founded in 1995, Luxury Beach Resort has been providing exceptional
                hospitality experiences for over two decades. Our commitment to excellence
                and attention to detail has made us a preferred destination for
                travelers seeking luxury by the ocean.
              </p>
              <p className="text-gray-600 mb-6">
                Set against the backdrop of pristine beaches and lush tropical gardens,
                our resort offers a perfect blend of natural beauty and modern luxury.
                Every aspect of our property is designed to provide an unforgettable
                experience for our guests.
              </p>
              <ul className="space-y-3">
                {[
                  '25 Years of Excellence',
                  'Award-winning Service',
                  'Sustainable Practices',
                  'Local Community Support',
                  'Luxury Amenities'
                ].map((feature, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <Check size={20} className="text-blue-600" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <img
                src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&q=80&w=600"
                alt="Resort exterior"
                className="rounded-lg shadow-lg"
              />
              <img
                src="https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=600"
                alt="Resort pool"
                className="rounded-lg shadow-lg mt-8"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <Slider
          items={teamMembers}
          renderItem={(member) => <TeamMemberCard {...member} />}
          title="Meet Our Team"
          subtitle="Dedicated professionals committed to making your stay exceptional"
        />
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <Slider
          items={testimonials}
          renderItem={(testimonial) => <TestimonialCard {...testimonial} />}
          title="Guest Stories"
          subtitle="Hear what our guests have to say about their experiences"
        />
      </section>

      {/* Booking CTA */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Experience Luxury</h2>
              <p className="text-lg mb-8">
                Join us for an unforgettable stay at our beachfront paradise.
                Book now and create lasting memories.
              </p>
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <Check size={24} className="text-white" />
                  <span>Best Rate Guarantee</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check size={24} className="text-white" />
                  <span>Free Cancellation</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check size={24} className="text-white" />
                  <span>Flexible Payment Options</span>
                </li>
              </ul>
            </div>
            <form onSubmit={handleBookingSubmit} className="bg-white p-6 rounded-lg text-gray-800">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Check-in Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="date"
                      required
                      value={bookingForm.checkIn}
                      onChange={(e) => setBookingForm({ ...bookingForm, checkIn: e.target.value })}
                      min={new Date().toISOString().split('T')[0]}
                      className="pl-10 w-full p-2 border rounded-lg"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Check-out Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="date"
                      required
                      value={bookingForm.checkOut}
                      onChange={(e) => setBookingForm({ ...bookingForm, checkOut: e.target.value })}
                      min={bookingForm.checkIn || new Date().toISOString().split('T')[0]}
                      className="pl-10 w-full p-2 border rounded-lg"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Guests</label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <select
                      value={bookingForm.guests}
                      onChange={(e) => setBookingForm({ ...bookingForm, guests: e.target.value })}
                      className="pl-10 w-full p-2 border rounded-lg"
                    >
                      {[1, 2, 3, 4, 5, 6].map((num) => (
                        <option key={num} value={num}>{num} Guest{num !== 1 ? 's' : ''}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Room Type</label>
                  <select
                    value={bookingForm.roomType}
                    onChange={(e) => setBookingForm({ ...bookingForm, roomType: e.target.value })}
                    className="w-full p-2 border rounded-lg"
                  >
                    {rooms.map((room) => (
                      <option key={room.id} value={room.name}>{room.name}</option>
                    ))}
                  </select>
                </div>
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Check Availability
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-20 bg-white">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Common Questions</h2>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <FAQItem key={index} {...faq} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};