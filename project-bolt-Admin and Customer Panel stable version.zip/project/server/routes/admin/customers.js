import express from 'express';
import { authenticateToken, isAdmin } from '../../middleware/auth.js';

const router = express.Router();

export default function customersRoutes(db) {
  // Get all customers with stats
  router.get('/', authenticateToken, isAdmin, async (req, res) => {
    try {
      const customers = await db.all(`
        SELECT 
          u.*,
          COUNT(b.id) as totalBookings,
          SUM(CASE WHEN b.status = 'confirmed' THEN 1 ELSE 0 END) as confirmedBookings,
          SUM(CASE WHEN b.status = 'pending' THEN 1 ELSE 0 END) as pendingBookings
        FROM users u
        LEFT JOIN bookings b ON u.email = b.customerEmail
        WHERE u.isAdmin = 0
        GROUP BY u.id
      `);

      const customersWithStats = await Promise.all(customers.map(async (customer) => {
        const recentBookings = await db.all(`
          SELECT id, roomName, checkIn, checkOut, status
          FROM bookings
          WHERE customerEmail = ?
          ORDER BY createdAt DESC
          LIMIT 3
        `, [customer.email]);

        return {
          ...customer,
          bookingStats: {
            total: customer.totalBookings || 0,
            confirmed: customer.confirmedBookings || 0,
            pending: customer.pendingBookings || 0
          },
          recentBookings
        };
      }));

      res.json({ success: true, customers: customersWithStats });
    } catch (error) {
      console.error('Fetch customers error:', error);
      res.status(500).json({ success: false, error: 'Failed to fetch customers' });
    }
  });

  return router;
}