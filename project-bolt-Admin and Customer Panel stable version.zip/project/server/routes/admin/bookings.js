import express from 'express';
import { authenticateToken, isAdmin } from '../../middleware/auth.js';

const router = express.Router();

export default function bookingsRoutes(db) {
  // Get all bookings
  router.get('/', authenticateToken, isAdmin, async (req, res) => {
    try {
      const bookings = await db.all(`
        SELECT 
          b.*,
          u.fullName as customerName,
          u.email as customerEmail
        FROM bookings b
        LEFT JOIN users u ON b.customerEmail = u.email
        ORDER BY b.createdAt DESC
      `);

      res.json({ success: true, bookings });
    } catch (error) {
      console.error('Fetch bookings error:', error);
      res.status(500).json({ success: false, error: 'Failed to fetch bookings' });
    }
  });

  // Create booking
  router.post('/', authenticateToken, isAdmin, async (req, res) => {
    try {
      const { customerEmail, customerName, roomName, checkIn, checkOut, guests, status = 'pending' } = req.body;
      
      const result = await db.run(`
        INSERT INTO bookings (customerEmail, customerName, roomName, checkIn, checkOut, guests, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [customerEmail, customerName, roomName, checkIn, checkOut, guests, status]);

      res.json({ 
        success: true, 
        bookingId: result.lastID,
        message: 'Booking created successfully'
      });
    } catch (error) {
      console.error('Create booking error:', error);
      res.status(500).json({ success: false, error: 'Failed to create booking' });
    }
  });

  // Update booking status
  router.put('/:id', authenticateToken, isAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      await db.run('UPDATE bookings SET status = ? WHERE id = ?', [status, id]);
      
      res.json({ 
        success: true,
        message: 'Booking status updated successfully'
      });
    } catch (error) {
      console.error('Update booking error:', error);
      res.status(500).json({ success: false, error: 'Failed to update booking' });
    }
  });

  return router;
}