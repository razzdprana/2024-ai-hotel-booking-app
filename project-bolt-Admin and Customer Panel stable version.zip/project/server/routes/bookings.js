import express from 'express';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

export default function bookingsRoutes(db) {
  // Get user's bookings
  router.get('/', authenticateToken, async (req, res) => {
    try {
      const { email } = req.query;
      
      const bookings = await db.all(`
        SELECT * FROM bookings 
        WHERE customerEmail = ?
        ORDER BY createdAt DESC
      `, [email]);

      res.json({ success: true, bookings });
    } catch (error) {
      console.error('Failed to fetch bookings:', error);
      res.status(500).json({ success: false, error: 'Failed to fetch bookings' });
    }
  });

  // Create booking
  router.post('/', authenticateToken, async (req, res) => {
    try {
      const { customerEmail, customerName, roomName, checkIn, checkOut, guests } = req.body;
      
      const result = await db.run(`
        INSERT INTO bookings (customerEmail, customerName, roomName, checkIn, checkOut, guests, status)
        VALUES (?, ?, ?, ?, ?, ?, 'pending')
      `, [customerEmail, customerName, roomName, checkIn, checkOut, guests]);

      res.json({ 
        success: true,
        bookingId: result.lastID,
        message: 'Booking created successfully'
      });
    } catch (error) {
      console.error('Failed to create booking:', error);
      res.status(500).json({ success: false, error: 'Failed to create booking' });
    }
  });

  return router;
}