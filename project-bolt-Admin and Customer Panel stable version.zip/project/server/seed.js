import { open } from 'sqlite';
import sqlite3 from 'sqlite3';
import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));

async function seed() {
  const db = await open({
    filename: join(__dirname, 'db', 'database.sqlite'),
    driver: sqlite3.Database
  });

  // Create admin user
  const adminPassword = await bcrypt.hash('admin123', 10);
  await db.run(`
    INSERT OR REPLACE INTO users (email, password, fullName, isAdmin, verified)
    VALUES (?, ?, ?, 1, 1)
  `, ['admin@hotel.com', adminPassword, 'Hotel Admin']);

  // Create demo customers
  const customers = [
    { email: 'john@example.com', fullName: 'John Doe', phone: '+1234567890' },
    { email: 'jane@example.com', fullName: 'Jane Smith', phone: '+1234567891' },
    { email: 'bob@example.com', fullName: 'Bob Johnson', phone: '+1234567892' },
    { email: 'alice@example.com', fullName: 'Alice Brown', phone: '+1234567893' },
    { email: 'mike@example.com', fullName: 'Mike Wilson', phone: '+1234567894' }
  ];

  const customerPassword = await bcrypt.hash('password123', 10);
  
  for (const customer of customers) {
    await db.run(`
      INSERT OR REPLACE INTO users (email, password, fullName, phone, isAdmin, verified)
      VALUES (?, ?, ?, ?, 0, 1)
    `, [customer.email, customerPassword, customer.fullName, customer.phone]);
  }

  // Create demo rooms
  const rooms = [
    {
      name: 'Deluxe Ocean View Suite',
      description: 'Luxurious suite with panoramic ocean views, king-size bed, and private balcony',
      price: 450,
      image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&q=80&w=1200',
      capacity: 2,
      amenities: JSON.stringify(['Ocean View', 'King Bed', 'Private Balcony', 'Mini Bar', 'Room Service']),
      status: 'published'
    },
    {
      name: 'Garden Villa',
      description: 'Spacious villa surrounded by tropical gardens with private pool',
      price: 750,
      image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=1200',
      capacity: 4,
      amenities: JSON.stringify(['Private Pool', 'Garden View', 'Kitchen', 'Living Room', 'Butler Service']),
      status: 'published'
    },
    {
      name: 'Executive Mountain Suite',
      description: 'Modern suite with mountain views and workspace',
      price: 350,
      image: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=1200',
      capacity: 2,
      amenities: JSON.stringify(['Mountain View', 'Work Desk', 'Lounge Area', 'High-Speed WiFi', 'Coffee Machine']),
      status: 'published'
    }
  ];

  for (const room of rooms) {
    await db.run(`
      INSERT OR REPLACE INTO rooms (name, description, price, image, capacity, amenities, status)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [room.name, room.description, room.price, room.image, room.capacity, room.amenities, room.status]);
  }

  // Create demo bookings
  const bookings = [
    {
      customerEmail: 'john@example.com',
      customerName: 'John Doe',
      roomName: 'Deluxe Ocean View Suite',
      checkIn: '2024-03-15',
      checkOut: '2024-03-20',
      guests: 2,
      status: 'confirmed'
    },
    {
      customerEmail: 'jane@example.com',
      customerName: 'Jane Smith',
      roomName: 'Garden Villa',
      checkIn: '2024-03-18',
      checkOut: '2024-03-25',
      guests: 4,
      status: 'pending'
    },
    {
      customerEmail: 'bob@example.com',
      customerName: 'Bob Johnson',
      roomName: 'Executive Mountain Suite',
      checkIn: '2024-03-20',
      checkOut: '2024-03-23',
      guests: 2,
      status: 'confirmed'
    },
    {
      customerEmail: 'alice@example.com',
      customerName: 'Alice Brown',
      roomName: 'Deluxe Ocean View Suite',
      checkIn: '2024-03-25',
      checkOut: '2024-03-30',
      guests: 2,
      status: 'pending'
    },
    {
      customerEmail: 'mike@example.com',
      customerName: 'Mike Wilson',
      roomName: 'Garden Villa',
      checkIn: '2024-04-01',
      checkOut: '2024-04-07',
      guests: 3,
      status: 'confirmed'
    }
  ];

  for (const booking of bookings) {
    await db.run(`
      INSERT OR REPLACE INTO bookings (customerEmail, customerName, roomName, checkIn, checkOut, guests, status)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [booking.customerEmail, booking.customerName, booking.roomName, booking.checkIn, booking.checkOut, booking.guests, booking.status]);
  }

  console.log('Database seeded successfully');
  await db.close();
}

seed().catch(console.error);