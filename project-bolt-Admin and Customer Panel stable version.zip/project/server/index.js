import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import morgan from 'morgan';
import { open } from 'sqlite';
import sqlite3 from 'sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';
import fs from 'fs/promises';

// Import routes
import bookingsRoutes from './routes/admin/bookings.js';
import customersRoutes from './routes/admin/customers.js';
import roomsRoutes from './routes/admin/rooms.js';
import statsRoutes from './routes/admin/stats.js';
import authRoutes from './routes/auth.js';
import userBookingsRoutes from './routes/bookings.js';

dotenv.config();

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(morgan('dev')); // Logging
app.use(express.json());
app.use(cookieParser());
app.use(cors({
  origin: 'http://localhost:5173',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type']
}));

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ 
    success: false, 
    error: process.env.NODE_ENV === 'development' ? err.message : 'Internal server error'
  });
});

// Database setup
const dbDir = join(__dirname, 'db');
const dbPath = join(dbDir, 'database.sqlite');

// Ensure database directory exists
await fs.mkdir(dbDir, { recursive: true });

// Initialize database connection
const db = await open({
  filename: dbPath,
  driver: sqlite3.Database
});

// Create tables
await db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT,
    fullName TEXT,
    phone TEXT,
    isAdmin INTEGER DEFAULT 0,
    verified INTEGER DEFAULT 1,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customerEmail TEXT,
    customerName TEXT,
    roomName TEXT,
    checkIn DATE,
    checkOut DATE,
    guests INTEGER,
    status TEXT DEFAULT 'pending',
    notes TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customerEmail) REFERENCES users(email)
  );

  CREATE TABLE IF NOT EXISTS rooms (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL,
    image TEXT,
    capacity INTEGER DEFAULT 1,
    amenities TEXT,
    status TEXT DEFAULT 'draft',
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Mount routes
app.use('/api/auth', authRoutes(db));
app.use('/api/admin/bookings', bookingsRoutes(db));
app.use('/api/admin/customers', customersRoutes(db));
app.use('/api/admin/rooms', roomsRoutes(db));
app.use('/api/admin/stats', statsRoutes(db));
app.use('/api/bookings', userBookingsRoutes(db));

// Health check route
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Start server
app.listen(PORT, 'localhost', () => {
  console.log(`Server running on http://localhost:${PORT}`);
});