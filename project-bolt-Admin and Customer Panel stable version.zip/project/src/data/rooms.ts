export const rooms = [
  {
    id: 1,
    name: "Deluxe Ocean View Suite",
    description: "Luxurious suite with panoramic ocean views, king-size bed, and private balcony",
    price: 450,
    image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&q=80&w=1200",
    capacity: 2,
    amenities: ["Ocean View", "King Bed", "Private Balcony", "Mini Bar", "Room Service"]
  },
  {
    id: 2,
    name: "Garden Villa",
    description: "Spacious villa surrounded by tropical gardens with private pool",
    price: 750,
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=1200",
    capacity: 4,
    amenities: ["Private Pool", "Garden View", "Kitchen", "Living Room", "Butler Service"]
  },
  {
    id: 3,
    name: "Executive Mountain Suite",
    description: "Modern suite with mountain views and workspace",
    price: 350,
    image: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=1200",
    capacity: 2,
    amenities: ["Mountain View", "Work Desk", "Lounge Area", "High-Speed WiFi", "Coffee Machine"]
  }
];