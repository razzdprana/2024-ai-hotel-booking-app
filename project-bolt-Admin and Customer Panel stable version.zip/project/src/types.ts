export interface Room {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  capacity: number;
  amenities: string[];
}

export interface BookingDetails {
  room: Room;
  checkIn: Date;
  checkOut: Date;
  guests: number;
  customerName: string;
  address: string;
  phoneNumber: string;
}