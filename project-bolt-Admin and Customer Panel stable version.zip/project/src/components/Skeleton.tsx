import React from 'react';

interface SkeletonProps {
  className?: string;
  variant?: 'text' | 'image' | 'button' | 'card' | 'avatar';
  count?: number;
}

export const Skeleton: React.FC<SkeletonProps> = ({ 
  className = '', 
  variant = 'text',
  count = 1
}) => {
  const baseClasses = "animate-pulse bg-gray-200 rounded";
  
  const getVariantClasses = () => {
    switch (variant) {
      case 'text':
        return 'h-4 w-full';
      case 'image':
        return 'h-48 w-full object-cover';
      case 'button':
        return 'h-10 w-24';
      case 'avatar':
        return 'h-12 w-12 rounded-full';
      case 'card':
        return 'h-[300px] w-full';
      default:
        return '';
    }
  };

  const renderSkeleton = () => (
    <div className={`${baseClasses} ${getVariantClasses()} ${className}`} />
  );

  if (count === 1) return renderSkeleton();

  return (
    <div className="space-y-3">
      {[...Array(count)].map((_, i) => (
        <div key={i}>{renderSkeleton()}</div>
      ))}
    </div>
  );
};

export const CardSkeleton = () => (
  <div className="bg-white rounded-lg shadow-md p-6 animate-pulse">
    <div className="h-48 bg-gray-200 rounded-lg mb-4" />
    <div className="space-y-3">
      <div className="h-6 bg-gray-200 rounded w-3/4" />
      <div className="h-4 bg-gray-200 rounded" />
      <div className="h-4 bg-gray-200 rounded w-5/6" />
    </div>
    <div className="flex justify-between items-center mt-4">
      <div className="h-8 bg-gray-200 rounded w-24" />
      <div className="h-10 bg-gray-200 rounded w-32" />
    </div>
  </div>
);

export const TestimonialSkeleton = () => (
  <div className="bg-white rounded-lg shadow-md p-6 animate-pulse">
    <div className="flex items-center gap-4 mb-4">
      <div className="h-12 w-12 bg-gray-200 rounded-full" />
      <div className="space-y-2">
        <div className="h-4 bg-gray-200 rounded w-32" />
        <div className="h-3 bg-gray-200 rounded w-24" />
      </div>
    </div>
    <div className="space-y-2">
      <div className="h-4 bg-gray-200 rounded" />
      <div className="h-4 bg-gray-200 rounded w-5/6" />
      <div className="h-4 bg-gray-200 rounded w-4/6" />
    </div>
  </div>
);

export const StatsSkeleton = () => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    {[...Array(4)].map((_, i) => (
      <div key={i} className="bg-white rounded-lg shadow-md p-6 animate-pulse">
        <div className="h-10 w-10 bg-gray-200 rounded-lg mb-4" />
        <div className="h-8 bg-gray-200 rounded w-24 mb-2" />
        <div className="h-4 bg-gray-200 rounded w-32" />
      </div>
    ))}
  </div>
);

export const TableRowSkeleton = () => (
  <tr className="animate-pulse">
    <td className="px-6 py-4 whitespace-nowrap">
      <div className="h-4 bg-gray-200 rounded w-32" />
    </td>
    <td className="px-6 py-4 whitespace-nowrap">
      <div className="h-4 bg-gray-200 rounded w-24" />
    </td>
    <td className="px-6 py-4 whitespace-nowrap">
      <div className="h-4 bg-gray-200 rounded w-28" />
    </td>
    <td className="px-6 py-4 whitespace-nowrap">
      <div className="h-4 bg-gray-200 rounded w-20" />
    </td>
  </tr>
);

export const FormSkeleton = () => (
  <div className="space-y-6 animate-pulse">
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {[...Array(2)].map((_, i) => (
        <div key={i}>
          <div className="h-4 bg-gray-200 rounded w-24 mb-2" />
          <div className="h-10 bg-gray-200 rounded w-full" />
        </div>
      ))}
    </div>
    <div>
      <div className="h-4 bg-gray-200 rounded w-24 mb-2" />
      <div className="h-32 bg-gray-200 rounded w-full" />
    </div>
    <div className="h-10 bg-gray-200 rounded w-full" />
  </div>
);