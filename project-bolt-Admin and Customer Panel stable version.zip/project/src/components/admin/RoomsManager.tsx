import React, { useState, useEffect } from 'react';
import { Edit2, Plus, Eye, EyeOff } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Skeleton } from '../Skeleton';

interface Room {
  id: number;
  name: string;
  description: string;
  price: number;
  image: string;
  capacity: number;
  amenities: string[];
  status: 'draft' | 'published';
  createdAt: string;
}

export const RoomsManager = () => {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchRooms();
  }, []);

  const fetchRooms = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/admin/rooms', {
        credentials: 'include'
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Failed to fetch rooms');
      }

      const data = await res.json();
      
      if (!data.success) {
        throw new Error(data.error || 'Failed to fetch rooms');
      }

      // Ensure amenities is always an array
      const formattedRooms = data.rooms.map((room: Room) => ({
        ...room,
        amenities: Array.isArray(room.amenities) ? room.amenities : []
      }));

      setRooms(formattedRooms);
    } catch (error) {
      console.error('Fetch rooms error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to load rooms');
      setRooms([]);
    } finally {
      setLoading(false);
    }
  };

  const toggleStatus = async (id: number, currentStatus: string) => {
    try {
      const newStatus = currentStatus === 'published' ? 'draft' : 'published';
      const res = await fetch(`/api/admin/rooms/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ status: newStatus }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Failed to update room status');
      }

      const data = await res.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to update room status');
      }

      setRooms(prev => prev.map(room => 
        room.id === id ? { ...room, status: newStatus } : room
      ));

      toast.success(`Room ${newStatus === 'published' ? 'published' : 'unpublished'} successfully`);
    } catch (error) {
      console.error('Update room status error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to update room status');
    }
  };

  if (loading) {
    return (
      <div>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Manage Rooms</h2>
          <button
            onClick={() => navigate('/admin/rooms/add')}
            className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus size={20} />
            Add Room
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow-md p-4">
              <Skeleton className="w-full h-48 rounded-lg mb-4" />
              <Skeleton className="h-6 w-3/4 mb-2" />
              <Skeleton className="h-4 w-full mb-4" />
              <div className="flex justify-between items-center">
                <Skeleton className="h-8 w-24" />
                <Skeleton className="h-8 w-20" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Manage Rooms</h2>
        <button
          onClick={() => navigate('/admin/rooms/add')}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus size={20} />
          Add Room
        </button>
      </div>

      {rooms.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg">
          <Eye className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No rooms found
          </h3>
          <p className="text-gray-500">
            Start by adding your first room
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rooms.map((room) => (
            <div
              key={room.id}
              className="bg-white rounded-lg shadow-md overflow-hidden"
            >
              <img
                src={room.image}
                alt={room.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-semibold">{room.name}</h3>
                  <div className="text-xl font-bold">${room.price}</div>
                </div>
                <p className="text-gray-600 text-sm mb-4">{room.description}</p>

                <div className="flex flex-wrap gap-2 mb-4">
                  {room.amenities.map((amenity, index) => (
                    <span
                      key={index}
                      className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full"
                    >
                      {amenity}
                    </span>
                  ))}
                </div>

                <div className="flex justify-between items-center pt-4 border-t">
                  <div className="text-sm text-gray-500">
                    Capacity: {room.capacity} guests
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => navigate(`/admin/rooms/edit/${room.id}`)}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      title="Edit room"
                    >
                      <Edit2 size={18} />
                    </button>
                    <button
                      onClick={() => toggleStatus(room.id, room.status)}
                      className={`p-2 rounded-lg transition-colors ${
                        room.status === 'published'
                          ? 'text-green-600 hover:bg-green-50'
                          : 'text-yellow-600 hover:bg-yellow-50'
                      }`}
                      title={room.status === 'published' ? 'Unpublish room' : 'Publish room'}
                    >
                      {room.status === 'published' ? (
                        <Eye size={18} />
                      ) : (
                        <EyeOff size={18} />
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};