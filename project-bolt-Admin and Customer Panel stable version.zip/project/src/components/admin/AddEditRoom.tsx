import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Save, Eye, ArrowLeft } from 'lucide-react';
import toast from 'react-hot-toast';

interface RoomFormData {
  name: string;
  description: string;
  price: number;
  image: string;
  capacity: number;
  amenities: string[];
  status: 'draft' | 'published';
}

export const AddEditRoom = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<RoomFormData>({
    name: '',
    description: '',
    price: 0,
    image: '',
    capacity: 1,
    amenities: [],
    status: 'draft'
  });

  useEffect(() => {
    if (id) {
      fetchRoom();
    }
  }, [id]);

  const fetchRoom = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/admin/rooms/${id}`, {
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Failed to fetch room');
      }

      const data = await res.json();
      
      if (!data.success) {
        throw new Error(data.error || 'Failed to fetch room');
      }

      // Ensure amenities is always an array
      setFormData({
        ...data.room,
        amenities: Array.isArray(data.room.amenities) ? data.room.amenities : []
      });
    } catch (error) {
      console.error('Fetch room error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to load room details');
      navigate('/admin/rooms');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (status: 'draft' | 'published') => {
    try {
      setLoading(true);
      const method = id ? 'PUT' : 'POST';
      const url = id ? `/api/admin/rooms/${id}` : '/api/admin/rooms';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ ...formData, status }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Failed to save room');
      }

      const data = await res.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to save room');
      }

      toast.success(data.message || 'Room saved successfully');
      navigate('/admin/rooms');
    } catch (error) {
      console.error('Save room error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to save room');
    } finally {
      setLoading(false);
    }
  };

  const handleAmenityChange = (amenity: string) => {
    setFormData(prev => ({
      ...prev,
      amenities: prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity]
    }));
  };

  const commonAmenities = [
    'Ocean View', 'Mountain View', 'King Bed', 'Queen Bed',
    'Private Balcony', 'Mini Bar', 'Room Service', 'Kitchen',
    'Living Room', 'Butler Service', 'High-Speed WiFi',
    'Coffee Machine', 'Smart TV', 'Air Conditioning'
  ];

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate('/admin/rooms')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft size={20} />
            Back to Rooms
          </button>
          <h2 className="text-2xl font-bold">{id ? 'Edit Room' : 'Add New Room'}</h2>
        </div>
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-10 bg-gray-200 rounded w-3/4"></div>
            <div className="h-32 bg-gray-200 rounded"></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="h-10 bg-gray-200 rounded"></div>
              <div className="h-10 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => navigate('/admin/rooms')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft size={20} />
          Back to Rooms
        </button>
        <h2 className="text-2xl font-bold">{id ? 'Edit Room' : 'Add New Room'}</h2>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <form onSubmit={(e) => e.preventDefault()} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Room Name
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="e.g., Deluxe Ocean View Suite"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              required
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={4}
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none resize-none"
              placeholder="Describe the room and its features..."
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Price per Night ($)
              </label>
              <input
                type="number"
                required
                min="0"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Maximum Capacity
              </label>
              <input
                type="number"
                required
                min="1"
                value={formData.capacity}
                onChange={(e) => setFormData({ ...formData, capacity: Number(e.target.value) })}
                className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Image URL
            </label>
            <input
              type="url"
              required
              value={formData.image}
              onChange={(e) => setFormData({ ...formData, image: e.target.value })}
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="https://example.com/room-image.jpg"
            />
            {formData.image && (
              <img
                src={formData.image}
                alt="Room preview"
                className="mt-2 w-full h-48 object-cover rounded-lg"
              />
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Amenities
            </label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {commonAmenities.map((amenity) => (
                <label
                  key={amenity}
                  className="flex items-center gap-2 text-sm"
                >
                  <input
                    type="checkbox"
                    checked={formData.amenities.includes(amenity)}
                    onChange={() => handleAmenityChange(amenity)}
                    className="rounded text-blue-600 focus:ring-blue-500"
                  />
                  {amenity}
                </label>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-4 pt-4 border-t">
            <button
              type="button"
              onClick={() => handleSubmit('draft')}
              disabled={loading}
              className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
            >
              <Save size={20} className="inline-block mr-2" />
              Save as Draft
            </button>
            <button
              type="button"
              onClick={() => handleSubmit('published')}
              disabled={loading}
              className="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Eye size={20} className="inline-block mr-2" />
              {id ? 'Update & Publish' : 'Save & Publish'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};