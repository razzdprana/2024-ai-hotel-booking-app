import React, { useState, useEffect } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import { Edit2, X } from 'lucide-react';
import toast from 'react-hot-toast';
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";

interface Booking {
  id: number;
  title: string;
  start: string;
  end: string;
  status: string;
  customerName: string;
  customerEmail: string;
  roomName: string;
  guests: number;
  notes: string;
  className: string;
}

export const BookingCalendar = () => {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const res = await fetch('/api/admin/bookings', {
        credentials: 'include'
      });

      if (!res.ok) {
        throw new Error('Failed to fetch bookings');
      }

      const data = await res.json();
      
      const formattedBookings = data.bookings.map((booking: any) => ({
        id: booking.id,
        title: `${booking.roomName} - ${booking.customerName}`,
        start: booking.checkIn,
        end: booking.checkOut,
        status: booking.status,
        customerName: booking.customerName,
        customerEmail: booking.customerEmail,
        roomName: booking.roomName,
        guests: booking.guests,
        notes: booking.notes || '',
        className: `calendar-event-${booking.status.toLowerCase()}`
      }));

      setBookings(formattedBookings);
    } catch (error) {
      console.error('Failed to fetch bookings:', error);
      toast.error('Failed to load bookings');
    } finally {
      setLoading(false);
    }
  };

  const handleEventClick = (info: any) => {
    const booking = bookings.find(b => b.id === parseInt(info.event.id));
    if (booking) {
      setSelectedBooking(booking);
    }
  };

  const handleDateChange = async (info: any) => {
    const { event } = info;
    const booking = bookings.find(b => b.id === parseInt(event.id));
    
    if (booking) {
      try {
        const res = await fetch(`/api/admin/bookings/${booking.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({
            checkIn: event.start.toISOString().split('T')[0],
            checkOut: event.end.toISOString().split('T')[0],
            status: booking.status,
            notes: booking.notes
          })
        });

        if (!res.ok) {
          throw new Error('Failed to update booking dates');
        }

        toast.success('Booking dates updated successfully');
        fetchBookings();
      } catch (error) {
        console.error('Failed to update booking dates:', error);
        toast.error('Failed to update booking dates');
        fetchBookings();
      }
    }
  };

  const handleStatusChange = async (status: string) => {
    if (!selectedBooking) return;

    try {
      const res = await fetch(`/api/admin/bookings/${selectedBooking.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          status,
          notes: selectedBooking.notes,
          checkIn: selectedBooking.start,
          checkOut: selectedBooking.end
        })
      });

      if (!res.ok) {
        throw new Error('Failed to update booking status');
      }

      toast.success('Booking status updated successfully');
      setSelectedBooking(null);
      fetchBookings();
    } catch (error) {
      console.error('Failed to update booking status:', error);
      toast.error('Failed to update booking status');
    }
  };

  const handleNotesChange = async (notes: string) => {
    if (!selectedBooking) return;

    try {
      const res = await fetch(`/api/admin/bookings/${selectedBooking.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          status: selectedBooking.status,
          notes,
          checkIn: selectedBooking.start,
          checkOut: selectedBooking.end
        })
      });

      if (!res.ok) {
        throw new Error('Failed to update booking notes');
      }

      toast.success('Booking notes updated successfully');
      setSelectedBooking({ ...selectedBooking, notes });
    } catch (error) {
      console.error('Failed to update booking notes:', error);
      toast.error('Failed to update booking notes');
    }
  };

  if (loading) {
    return <div>Loading calendar...</div>;
  }

  return (
    <div className="h-[calc(100vh-2rem)]">
      <style>
        {`
          .calendar-event-confirmed {
            background-color: #86EFAC !important;
            border-color: #16A34A !important;
            color: #166534 !important;
          }
          .calendar-event-pending {
            background-color: #FDE68A !important;
            border-color: #D97706 !important;
            color: #92400E !important;
          }
          .calendar-event-cancelled {
            background-color: #FCA5A5 !important;
            border-color: #DC2626 !important;
            color: #991B1B !important;
          }
        `}
      </style>

      <div className="mb-6 flex justify-between items-center">
        <h2 className="text-2xl font-bold">Booking Calendar</h2>
      </div>

      <div className="relative">
        <FullCalendar
          plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
          initialView="dayGridMonth"
          headerToolbar={{
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
          }}
          events={bookings}
          eventClick={handleEventClick}
          editable={true}
          eventDrop={handleDateChange}
          eventResize={handleDateChange}
          height="100%"
          dayMaxEvents={true}
          eventTimeFormat={{
            hour: '2-digit',
            minute: '2-digit',
            meridiem: false
          }}
        />

        {selectedBooking && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Booking Details</h3>
                <button
                  onClick={() => setSelectedBooking(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Customer
                  </label>
                  <p className="text-gray-900">{selectedBooking.customerName}</p>
                  <p className="text-sm text-gray-500">{selectedBooking.customerEmail}</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Room
                  </label>
                  <p className="text-gray-900">{selectedBooking.roomName}</p>
                  <p className="text-sm text-gray-500">{selectedBooking.guests} guests</p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Status
                  </label>
                  <select
                    value={selectedBooking.status}
                    onChange={(e) => handleStatusChange(e.target.value)}
                    className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Notes
                  </label>
                  <textarea
                    value={selectedBooking.notes}
                    onChange={(e) => handleNotesChange(e.target.value)}
                    rows={3}
                    className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};