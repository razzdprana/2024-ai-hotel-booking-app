import React, { useState, useEffect } from 'react';
import { BookOpen, User, FileText, LogOut, Home, Menu, X } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../../contexts/AuthContext';

interface DashboardNavProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

export const DashboardNav: React.FC<DashboardNavProps> = ({ activeSection, onSectionChange }) => {
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 1024);
  const navigate = useNavigate();
  const { logout } = useAuth();

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
      if (window.innerWidth >= 1024) {
        setIsNavOpen(true);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleLogout = async () => {
    try {
      await logout();
      toast.success('Logged out successfully');
      navigate('/login');
    } catch (error) {
      toast.error('Failed to logout');
    }
  };

  const navItems = [
    { id: 'bookings', label: 'My Bookings', icon: BookOpen },
    { id: 'profile', label: 'My Profile', icon: User },
    { id: 'documents', label: 'My Documents', icon: FileText },
  ];

  return (
    <>
      {isMobile && (
        <button
          onClick={() => setIsNavOpen(!isNavOpen)}
          className="fixed top-4 left-4 z-50 bg-white p-2 rounded-lg shadow-lg hover:bg-gray-50 transition-colors"
          aria-label={isNavOpen ? 'Close menu' : 'Open menu'}
        >
          {isNavOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      )}

      {isMobile && isNavOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={() => setIsNavOpen(false)}
        />
      )}

      <nav
        className={`
          fixed lg:sticky top-0 left-0 h-screen w-64 bg-white shadow-lg z-40
          flex flex-col overflow-hidden
          transition-transform duration-300 ease-in-out
          ${isMobile ? (isNavOpen ? 'translate-x-0' : '-translate-x-full') : 'translate-x-0'}
        `}
      >
        {/* Header */}
        <div className="p-6 border-b bg-white">
          <h2 className="text-2xl font-bold text-gray-800">Dashboard</h2>
        </div>

        {/* Navigation Items */}
        <div className="flex-1 overflow-y-auto py-6">
          <div className="px-4 space-y-2">
            {navItems.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => {
                  onSectionChange(id);
                  if (isMobile) setIsNavOpen(false);
                }}
                className={`
                  w-full flex items-center gap-3 px-4 py-3 
                  text-sm font-medium rounded-lg transition-colors
                  ${activeSection === id
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-600 hover:bg-gray-50'
                  }
                `}
              >
                <Icon size={20} />
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t bg-white mt-auto">
          <Link
            to="/"
            className="flex items-center gap-3 w-full px-4 py-3 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors mb-2"
          >
            <Home size={20} />
            <span className="font-medium">Back to Home</span>
          </Link>
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 w-full px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            <LogOut size={20} />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </nav>
    </>
  );
};