import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface SliderProps {
  items: any[];
  renderItem: (item: any) => React.ReactNode;
  title: string;
  subtitle?: string;
}

export const Slider: React.FC<SliderProps> = ({ items, renderItem, title, subtitle }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const next = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prevIndex) => (prevIndex + 1) % items.length);
    setTimeout(() => setIsAnimating(false), 500);
  };

  const prev = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prevIndex) => (prevIndex - 1 + items.length) % items.length);
    setTimeout(() => setIsAnimating(false), 500);
  };

  // Calculate visible items (3 items starting from currentIndex)
  const visibleItems = [...items.slice(currentIndex), ...items.slice(0, currentIndex)]
    .slice(0, 3);

  return (
    <div className="max-w-7xl mx-auto px-4">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold mb-4">{title}</h2>
        {subtitle && <p className="text-gray-600 max-w-2xl mx-auto">{subtitle}</p>}
      </div>

      <div className="relative overflow-hidden">
        <div 
          className={`flex gap-6 transition-transform duration-500 ease-in-out ${
            isAnimating ? 'opacity-90 scale-[0.98]' : 'opacity-100 scale-100'
          }`}
        >
          {visibleItems.map((item, index) => (
            <div key={index} className="flex-1 transition-all duration-500">
              {renderItem(item)}
            </div>
          ))}
        </div>

        <button
          onClick={prev}
          disabled={isAnimating}
          className="absolute -left-4 top-1/2 -translate-y-1/2 bg-white p-2 rounded-full shadow-lg hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          aria-label="Previous slide"
        >
          <ChevronLeft size={24} />
        </button>
        <button
          onClick={next}
          disabled={isAnimating}
          className="absolute -right-4 top-1/2 -translate-y-1/2 bg-white p-2 rounded-full shadow-lg hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          aria-label="Next slide"
        >
          <ChevronRight size={24} />
        </button>
      </div>
    </div>
  );
};