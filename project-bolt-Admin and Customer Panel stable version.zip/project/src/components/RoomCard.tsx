import React from 'react';
import { Room } from '../types';
import { Bed, Users, Check } from 'lucide-react';

interface RoomCardProps {
  room: Room;
  onSelect: (room: Room) => void;
}

export const RoomCard: React.FC<RoomCardProps> = ({ room, onSelect }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-[1.02]">
      <img 
        src={room.image} 
        alt={room.name} 
        className="w-full h-40 sm:h-48 object-cover"
      />
      <div className="p-3 sm:p-4">
        <h3 className="text-lg sm:text-xl font-semibold text-gray-800">{room.name}</h3>
        <p className="text-sm sm:text-base text-gray-600 mt-1 sm:mt-2">{room.description}</p>
        
        <div className="flex flex-wrap items-center gap-3 sm:gap-4 mt-2 sm:mt-3 text-gray-600">
          <div className="flex items-center gap-1">
            <Bed size={16} className="sm:w-[18px] sm:h-[18px]" />
            <span className="text-xs sm:text-sm">King Bed</span>
          </div>
          <div className="flex items-center gap-1">
            <Users size={16} className="sm:w-[18px] sm:h-[18px]" />
            <span className="text-xs sm:text-sm">Up to {room.capacity} guests</span>
          </div>
        </div>

        <div className="mt-3 sm:mt-4">
          <h4 className="text-xs sm:text-sm font-semibold text-gray-700 mb-1 sm:mb-2">Amenities:</h4>
          <div className="flex flex-wrap gap-1.5 sm:gap-2">
            {room.amenities.map((amenity, index) => (
              <span 
                key={index}
                className="flex items-center gap-1 text-xs bg-gray-100 text-gray-600 px-2 py-0.5 sm:py-1 rounded-full"
              >
                <Check size={10} className="sm:w-3 sm:h-3" />
                {amenity}
              </span>
            ))}
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <div className="text-gray-800">
            <span className="text-xl sm:text-2xl font-bold">${room.price}</span>
            <span className="text-xs sm:text-sm text-gray-600">/night</span>
          </div>
          <button
            onClick={() => onSelect(room)}
            className="bg-blue-600 text-white px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm sm:text-base"
          >
            Select Room
          </button>
        </div>
      </div>
    </div>
  );
};