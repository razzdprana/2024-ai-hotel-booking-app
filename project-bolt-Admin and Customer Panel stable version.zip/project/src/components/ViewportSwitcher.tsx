import React from 'react';
import { Smartphone, Tablet, Monitor } from 'lucide-react';

const viewports = [
  { id: 'desktop', label: 'Desktop', icon: Monitor, width: '100%' },
  { id: 'tablet', label: 'Tablet', icon: Tablet, width: '768px' },
  { id: 'mobile', label: 'Mobile', icon: Smartphone, width: '375px' }
];

interface ViewportSwitcherProps {
  activeViewport: string;
  onViewportChange: (viewport: string) => void;
}

export const ViewportSwitcher: React.FC<ViewportSwitcherProps> = ({
  activeViewport,
  onViewportChange
}) => {
  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] bg-white px-4 py-2 rounded-lg shadow-lg flex gap-2">
      {viewports.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          onClick={() => onViewportChange(id)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors ${
            activeViewport === id
              ? 'bg-blue-100 text-blue-600'
              : 'hover:bg-gray-100 text-gray-600'
          }`}
          title={label}
        >
          <Icon size={20} />
          <span className="text-sm font-medium hidden sm:inline">{label}</span>
        </button>
      ))}
    </div>
  );
};