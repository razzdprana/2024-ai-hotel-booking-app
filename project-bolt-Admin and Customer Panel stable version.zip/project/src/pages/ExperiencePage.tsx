import React, { useState } from 'react';
import { Calendar, Users, Check, Star, Plus, Minus } from 'lucide-react';
import { rooms } from '../data/rooms';
import { Slider } from '../components/Slider';

interface Experience {
  title: string;
  description: string;
  image: string;
}

interface FAQ {
  question: string;
  answer: string;
}

const ambienceExperiences: Experience[] = [
  {
    title: "Beachfront Infinity Pool",
    description: "Immerse yourself in our stunning infinity pool that seems to merge with the ocean horizon.",
    image: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?auto=format&fit=crop&q=80&w=1200"
  },
  {
    title: "Sunset Lounge",
    description: "Enjoy breathtaking sunsets from our elevated lounge with panoramic ocean views.",
    image: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&q=80&w=1200"
  },
  {
    title: "Tropical Gardens",
    description: "Wander through our meticulously maintained gardens featuring local flora.",
    image: "https://images.unsplash.com/photo-1588683301419-7f5e39226b7c?auto=format&fit=crop&q=80&w=1200"
  },
  {
    title: "Private Beach Access",
    description: "Step directly onto pristine white sands from our exclusive beach access.",
    image: "https://images.unsplash.com/photo-1510414842594-a61c69b5ae57?auto=format&fit=crop&q=80&w=1200"
  }
];

const diningExperiences: Experience[] = [
  {
    title: "Ocean View Restaurant",
    description: "Fine dining with panoramic views and international cuisine crafted by award-winning chefs.",
    image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&q=80&w=1200"
  },
  {
    title: "Beachside Grill",
    description: "Fresh seafood and grilled specialties served in a casual beachfront setting.",
    image: "https://images.unsplash.com/photo-1502301103665-0b95cc738daf?auto=format&fit=crop&q=80&w=1200"
  },
  {
    title: "Sunset Bar",
    description: "Signature cocktails and tapas with stunning sunset views over the ocean.",
    image: "https://images.unsplash.com/photo-1470337458703-46ad1756a187?auto=format&fit=crop&q=80&w=1200"
  },
  {
    title: "Private Dining",
    description: "Intimate dining experiences in unique locations around the resort.",
    image: "https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&q=80&w=1200"
  }
];

const nearbyExperiences: Experience[] = [
  {
    title: "Snorkeling Adventures",
    description: "Explore vibrant coral reefs and marine life in crystal-clear waters.",
    image: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&q=80&w=1200"
  },
  {
    title: "Island Hopping",
    description: "Discover nearby islands and hidden beaches by private boat.",
    image: "https://images.unsplash.com/photo-1506929562872-bb421503ef21?auto=format&fit=crop&q=80&w=1200"
  },
  {
    title: "Cultural Tours",
    description: "Experience local traditions, markets, and historical sites.",
    image: "https://images.unsplash.com/photo-1519677100203-a0e668c92439?auto=format&fit=crop&q=80&w=1200"
  },
  {
    title: "Water Sports",
    description: "From jet skiing to parasailing, experience thrilling water activities.",
    image: "https://images.unsplash.com/photo-1533184580123-b704c4142c61?auto=format&fit=crop&q=80&w=1200"
  }
];

const faqs: FAQ[] = [
  {
    question: "Do I need to book activities in advance?",
    answer: "Yes, we recommend booking activities at least 24 hours in advance to ensure availability. Some seasonal activities may require earlier booking."
  },
  {
    question: "Are dining reservations required?",
    answer: "Reservations are recommended for our fine dining restaurant and special dining experiences, especially during peak season."
  },
  {
    question: "What's included in the cultural tours?",
    answer: "Our cultural tours include transportation, guide, entrance fees, and refreshments. Some tours also include traditional meals and craft workshops."
  },
  {
    question: "Are water sports suitable for beginners?",
    answer: "Yes, we offer activities for all skill levels. Certified instructors provide training and safety briefings for beginners."
  }
];

const ExperienceCard: React.FC<Experience> = ({ title, description, image }) => (
  <div className="bg-white rounded-lg shadow-lg overflow-hidden h-full">
    <img 
      src={image} 
      alt={title}
      className="w-full h-48 object-cover"
    />
    <div className="p-6">
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  </div>
);

const FAQItem: React.FC<FAQ> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border rounded-lg">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-4 text-left"
      >
        <span className="font-medium">{question}</span>
        {isOpen ? (
          <Minus size={20} className="text-gray-500" />
        ) : (
          <Plus size={20} className="text-gray-500" />
        )}
      </button>
      {isOpen && (
        <div className="px-4 pb-4 text-gray-600">
          {answer}
        </div>
      )}
    </div>
  );
};

export const ExperiencePage = () => {
  const [bookingForm, setBookingForm] = useState({
    checkIn: '',
    checkOut: '',
    guests: '2',
    roomType: rooms[0]?.name || ''
  });

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle booking submission
  };

  return (
    <div>
      {/* Header Section */}
      <div 
        className="h-[60vh] bg-cover bg-center relative"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1540541338287-41700207dee6?auto=format&fit=crop&q=80&w=1920")'
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="absolute inset-0 flex items-center justify-center p-4">
          <div className="text-center text-white max-w-4xl">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Unforgettable Experiences
            </h1>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Discover a world of exceptional experiences crafted to create lasting memories
            </p>
          </div>
        </div>
      </div>

      {/* Ambience Section */}
      <section className="py-20 bg-white">
        <Slider
          items={ambienceExperiences}
          renderItem={(experience) => <ExperienceCard {...experience} />}
          title="Resort Ambience"
          subtitle="Immerse yourself in the luxurious atmosphere of our resort"
        />
      </section>

      {/* Dining Section */}
      <section className="py-20 bg-gray-50">
        <Slider
          items={diningExperiences}
          renderItem={(experience) => <ExperienceCard {...experience} />}
          title="Food & Dining"
          subtitle="Savor exceptional culinary experiences in stunning settings"
        />
      </section>

      {/* Nearby Experiences */}
      <section className="py-20 bg-white">
        <Slider
          items={nearbyExperiences}
          renderItem={(experience) => <ExperienceCard {...experience} />}
          title="Nearby Adventures"
          subtitle="Explore exciting activities and attractions in the area"
        />
      </section>

      {/* Booking CTA */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Start Your Adventure</h2>
              <p className="text-lg mb-8">
                Book your stay now and experience all that our resort has to offer.
                Our concierge team will help plan your perfect itinerary.
              </p>
              <ul className="space-y-4">
                <li className="flex items-center gap-3">
                  <Check size={24} className="text-white" />
                  <span>Personalized Experience Planning</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check size={24} className="text-white" />
                  <span>Priority Activity Booking</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check size={24} className="text-white" />
                  <span>Exclusive Access to Events</span>
                </li>
              </ul>
            </div>
            <form onSubmit={handleBookingSubmit} className="bg-white p-6 rounded-lg text-gray-800">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Check-in Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="date"
                      required
                      value={bookingForm.checkIn}
                      onChange={(e) => setBookingForm({ ...bookingForm, checkIn: e.target.value })}
                      min={new Date().toISOString().split('T')[0]}
                      className="pl-10 w-full p-2 border rounded-lg"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Check-out Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <input
                      type="date"
                      required
                      value={bookingForm.checkOut}
                      onChange={(e) => setBookingForm({ ...bookingForm, checkOut: e.target.value })}
                      min={bookingForm.checkIn || new Date().toISOString().split('T')[0]}
                      className="pl-10 w-full p-2 border rounded-lg"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Guests</label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                    <select
                      value={bookingForm.guests}
                      onChange={(e) => setBookingForm({ ...bookingForm, guests: e.target.value })}
                      className="pl-10 w-full p-2 border rounded-lg"
                    >
                      {[1, 2, 3, 4, 5, 6].map((num) => (
                        <option key={num} value={num}>{num} Guest{num !== 1 ? 's' : ''}</option>
                      ))}
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Room Type</label>
                  <select
                    value={bookingForm.roomType}
                    onChange={(e) => setBookingForm({ ...bookingForm, roomType: e.target.value })}
                    className="w-full p-2 border rounded-lg"
                  >
                    {rooms.map((room) => (
                      <option key={room.id} value={room.name}>{room.name}</option>
                    ))}
                  </select>
                </div>
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Check Availability
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-20 bg-white">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Common Questions</h2>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <FAQItem key={index} {...faq} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};